Names: Daniel Tsivkovski and Tom Moore
Emails: tsivkovski@chapman.edu, thomoore@chapman.edu
ID: Daniel: 2456881 and Tom: 2444464
Course: CPSC350-03, CPSC350-04
Assignment 5
-----
Submitted Files:
-Database.cpp
-Database.H
-DblList.h
-Faculty.cpp
-Faculty.h
-FacultyBST.cpp
-FacultyBST.h
-LazyBSt.h
-ListNode.h
-Main.cpp
-Student.cpp
-Student.h
-StudentBST.cpp
-StudentBST.h
-----
References:
Used this to check if an inccorect cin was input:
https://stackoverflow.com/questions/18728754/checking-cin-input-stream-produces-an-integer

Used this to retry cin if failed:
https://stackoverflow.com/questions/7413247/cin-clear-doesnt-reset-cin-object

----- 
How to run:
- Compile in the docker container using: `g++ *.cpp`
- Run the code using `./a.out
- Follow the options that the terminal gives you
